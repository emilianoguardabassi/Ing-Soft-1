"""holds api version."""

__API__VERSION = "0.1.0"
