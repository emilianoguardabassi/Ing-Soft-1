"""Tags constants."""

DEFAULT_TAGS = ["Work", "Family", "Personal", "Educational", "Travel"]
